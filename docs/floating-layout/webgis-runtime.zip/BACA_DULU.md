# Paket runtime WebGIS — siap review

Sumber runtime: d6c88684e124d03c755239567ae3e5f177d9cd47
Repositori: https://github.com/itskindamia/webgis-transportasi-jabodetabek
Branch: codex/floating-network-layout

Paket ini adalah penggantian penuh runtime statis, bukan overlay potongan kode.
`index.html`, `assets/`, `css/`, `data/`, dan `js/` disertakan lengkap.
Empat GeoJSON, mesin transportasi, logo, ikon, PT Sans lokal 400/700, dan CSS
hasil build tersedia. `node_modules` tidak dibutuhkan untuk menjalankan runtime.
Dependensi development dan tes ada di branch sumber beserta package-lock.json.

## Preview lokal

1. Ekstrak ZIP ke folder kosong.
2. Dari folder itu, jalankan `python3 -m http.server 8000`.
3. Buka http://localhost:8000/ di browser. Jangan buka index.html melalui file://.

Koneksi internet tetap diperlukan untuk Leaflet 1.9.4 dari CDN (dengan SRI dan
fallback CDN), tile basemap serta pencarian tempat daring, sesuai konfigurasi
proyek semula. Font, data jaringan, logo, ikon dan CSS aplikasi disertakan lokal.
GPS memerlukan izin browser; localhost atau HTTPS diperlukan untuk lokasi.

## Penerapan setelah review

Tugas ini belum melakukan merge atau deploy. Sesudah disetujui, backup runtime
lama, lalu ganti index.html serta keempat direktori runtime dengan isi paket ini.
Jangan menyalin .git, node_modules, atau kredensial ke hosting. Daftar hash file
tersedia di SHA256SUMS. Lisensi komponen tetap ada dalam paket.
