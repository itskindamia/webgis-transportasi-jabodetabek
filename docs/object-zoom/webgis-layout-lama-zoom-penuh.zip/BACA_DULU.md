# WebGIS — layout lama, zoom objek penuh

Sumber runtime: 12610754e32fa1377e8a37e19ed870ee93818751
Layout dasar: 46c3913042934b67712327d566e34c287178845e
Versi: full-object-zoom-20261109-2

Paket penggantian penuh runtime statis: index.html, assets/, css/, data/, js/,
dan lisensi disertakan lengkap. Tidak memuat layout floating eksperimental.
Data jaringan, font PT Sans dan struktur panel mengikuti layout dasar.

Zoom rute menggunakan seluruh geometri tanpa tambahan buffer geografis.
Langkah zoom pecahan membuat extent lebih rapat mengisi ruang peta yang tersedia.
Kontrol peta dan panel yang terlihat tetap mendapat ruang. Tombol Pusatkan
memakai extent yang sama tanpa menghapus pilihan rute atau filter.

## Preview

Ekstrak ke folder kosong, jalankan python3 -m http.server 8000 dari folder itu,
lalu buka http://localhost:8000/. Jangan membuka index.html melalui file://.
CDN Leaflet, tile basemap, dan geocoding tetap memerlukan internet.
SHA256SUMS memuat hash seluruh berkas paket selain daftar hash itu sendiri.

Paket ini disiapkan untuk review. Merge dan deployment tidak dilakukan oleh
script packaging ini. Simpan salinan runtime lama sebelum mengganti hosting.
